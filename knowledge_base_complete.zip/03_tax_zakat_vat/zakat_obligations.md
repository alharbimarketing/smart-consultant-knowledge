# Zakat Obligations.Md

محتوى مبدئي للملف: zakat_obligations.md